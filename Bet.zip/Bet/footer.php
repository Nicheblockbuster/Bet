</div>

    <footer id="footer" class="main-footer">
      <div class="footer">
        <div class="footer-logo__wrap">
          <img src="/assets/logo.png" class="footer-logo" alt="footer-logo" />
        <img
          src="/assets/gambleaware-helpline-logo-vector_2@2x.png"
          alt="gambleaware-helpline-logo-vect"
          class="gambleaware-helpline-logo-vect"
        />
          </div>

        <div class="don-t-gamble-unless">
          <div>
            <p>
              Don't gamble unless you know the facts. Being responsible about
              gambling means knowing whether to gamble, how much money or how
              much time. Visit BeGambleaware.co.uk for more information.
            </p>
            <p>
              You must be 18+ to use this website.We have a privacy policy. By
              continuing to use this site, you are providing consent to it.
            </p>
            <p>
              We try hard to make sure that the site is up to date at all times.
              However, sometimes things happen beyond our control. Therefore, we
              assume no responsibility for actions taken as a result of
              information on this site (which does not constitute advice) and
              always recommend you to check terms and conditions before placing
              any bet.
            </p>
          </div>
            <span class="the-bet-calcu"> © 2019 The Bet Calculator</span>
         
        </div>
      </div>
      <div class="footer-info">
        <ul class="footer-info__items">
          <li data-toggle="modal" data-target=".bd-example-modal-lg"><a href="#">Terms & Conditions</a></li>
          <li><a href="#footer">Privacy Policy</a></li>
        </ul>
      </div>


   
        <!-- Large modal -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content terms-conditions">
      <div>
        <button type="button" class="close cross-btn" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="terms-conditions_details">
          <span class="terms-conditions_title">Terms & Conditions</span>
          <p>
          <p>

            A free bet is, or should in theory, be exactly that, a bet which is given to you for free which you can then place with a chance to win real money. In reality though it is more complicated than that with terms and conditions varying with every bookmaker around their free bet or sign up offers. 
          </p>  
            <p>

              We try to explain the free bet and sign up bonus offers here for you as much as possible given the space but please click through to the online bookmakers and read their terms and conditions in full before signing up. 
            </p>
              <p>

                Many of the betting offers will require you to deposit money first and place a bet. This first bet or qualifying bet will often need to be placed at certain odds. For example this condition may read something like this 
              </p>
<p>

  “the qualifying bet must have minimum odds of 4/5”
</p>
<p>

  Often the first bet you place is the qualifying bet and the amount of that bet will be matched (up to a certain amount) with a free bet of the same amount. 
</p>

<p>

  
  There are many variations though from the more simple bet £10 get £10 free bet to Bet £10 get £20, Bet £10 get £30 in free bets or even bet £20 get £10. 
</p>
  <p>

    Normally the main sign up offer for the bookmaker is available to use on all sports. But be careful to check as sometimes offers are for horse racing or football only. If you are looking for good bets to use on the qualifying stake to get your free bet, then check out our top tipsters predictions including our horse racing tips here. 
  </p>
    <p>

      A free bet is, or should in theory, be exactly that, a bet which is given to you for free which you can then place with a chance to win real money. In reality though it is more complicated than that with terms and conditions varying with every bookmaker around their free bet or sign up offers. 
    </p>
<p>

  We try to explain the free bet and sign up bonus offers here for you as much as possible given the space but please click through to the online bookmakers and read their terms and conditions in full before signing up. 
</p>
<p>
  
  Many of the betting offers will require you to deposit money first and place a bet. This first bet or qualifying bet will often need to be placed at certain odds. For example this condition may read something like this 
</p>
<p>

  “the qualifying bet must have minimum odds of 4/5”
</p>  
  <p>

    Often the first bet you place is the qualifying bet and the amount of that bet will be matched (up to a certain amount) with a free bet of the same amount. 
    
  </p>
  <p>

    There are many variations though from the more simple bet £10 get £10 free bet to Bet £10 get £20, Bet £10 get £30 in free bets or even bet £20 get £10. 
    
  </p>
  <p>

    Normally the main sign up offer for the bookmaker is available to use on all sports. But be careful to check as sometimes offers are for horse racing or football only. If you are looking for good bets to use on the qualifying stake to get your free bet, then check out our top tipsters predictions including our horse racing tips here. 
  </p>
  </div>
 
  </div>
</div>
</div>





    </footer>
    
    <script src="/js/script.js"></script>
  </body>
</html>
